/**
 * CR Mifnity
 * Roblox User Stalker
 * CMD  : .roblox <username>
 * API  : https://api.zenzxz.my.id/api/stalker/roblox?user=<username>
 * CH   : https://whatsapp.com/channel/0029VbBnJzJ8F2p4xCzrMW2X
 * NOTE : JANGAN HAPUS WM BANGGG!!
 */

import axios from "axios";

export default {
  name: "roblox",
  category: "stalker",
  command: ["roblox"],
  run: async (conn, m, { text, args, quoted }) => {
    const user =
      text ||
      (args && args.join(" ")) ||
      (quoted && quoted.text) ||
      (m.quoted && m.quoted.text);

    if (!user)
      return m.reply("❌ Masukkan username!\nContoh: .roblox mamixxx");

    try {
      const { data } = await axios.get(
        `https://api.zenzxz.my.id/api/stalker/roblox?user=${encodeURIComponent(
          user
        )}`
      );

      if (!data?.success || !data?.data)
        throw new Error("Gagal mengambil data dari API Roblox.");

      const info = data.data;
      const basic = info.basic || {};
      const avatar = info.avatar?.fullBody?.data?.[0]?.imageUrl;
      const group = info.groups?.list?.data?.[0]?.group;
      const badge = info.achievements?.robloxBadges?.[0];

      let teks = `🎮 *Roblox Stalker Result*\n\n`;
      teks += `👤 *Username:* ${basic.name || "-"}\n`;
      teks += `🏷️ *Display Name:* ${basic.displayName || "-"}\n`;
      teks += `🆔 *User ID:* ${basic.id || "-"}\n`;
      teks += `📅 *Akun Dibuat:* ${basic.created ? new Date(basic.created).toLocaleString("id-ID") : "-"}\n`;
      teks += `🚫 *Status Ban:* ${basic.isBanned ? "Ya" : "Tidak"}\n\n`;

      teks += `👥 *Friends:* ${info.social?.friends?.count || 0}\n`;
      teks += `👣 *Followers:* ${info.social?.followers?.count || 0}\n`;
      teks += `➡️ *Following:* ${info.social?.following?.count || 0}\n\n`;

      if (group) {
        teks += `🏢 *Group:* ${group.name}\n`;
        teks += `🧑‍💼 *Owner:* ${group.owner?.username || "-"}\n`;
        teks += `👥 *Member:* ${group.memberCount || 0}\n\n`;
      }

      if (badge) {
        teks += `🏅 *Badge:* ${badge.name}\n`;
        teks += `📖 *Deskripsi:* ${badge.description}\n\n`;
      }

      teks += `🧩 *Avatar Type:* ${info.avatar?.details?.playerAvatarType || "-"}\n`;
      teks += `👕 *Pakaian:* ${
        info.avatar?.details?.assets
          ?.filter((a) => ["Shirt", "Pants"].includes(a.assetType?.name))
          .map((a) => a.name)
          .join(", ") || "-"
      }\n\n`;

      teks += `🕒 *Terakhir diperbarui:* ${new Date(
        data.timestamp
      ).toLocaleString("id-ID")}`;

      if (avatar) {
        await conn.sendMessage(
          m.chat,
          {
            image: { url: avatar },
            caption: teks,
          },
          { quoted: m }
        );
      } else {
        await m.reply(teks);
      }
    } catch (err) {
      console.error("Error Roblox:", err.message);
      await m.reply("❌ Terjadi kesalahan saat mengambil data Roblox!");
    }
  },
};