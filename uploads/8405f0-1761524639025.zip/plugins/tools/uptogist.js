import axios from "axios";

export default {
  name: "uptogist",
  category: "tools",
  command: ["uptogist", "gist", "uploadgist"],
  settings: {
    owner: true
  },
  run: async (conn, m, context) => {
    try {
      const { args = [], text = "", command = "" } = context || {};
      const token = global.githubToken;
      if (!token) return m.reply("⚠️ *Token GitHub belum diset di config.js!* (global.githubToken)");

      const prefix = global.prefix || ".";
      const cmd = command || "gist";

      // ambil teks mentah dari pesan user
      const rawText = m.text?.trim() || "";

      // hapus prefix + nama command dari awal teks
      const cleanText = rawText.replace(new RegExp(`^\\${prefix}${cmd}\\s*`, "i"), "").trim();

      // aman dari undefined
      const argsText = Array.isArray(args) ? args.join(" ") : "";

      let filename = "";
      let content = "";
      let isRaw = false;

      // deteksi mode raw
      if (argsText.includes("raw") || /--raw/i.test(cleanText)) isRaw = true;

      // jika user reply teks/code
      if (m.quoted && m.quoted.text && !cleanText.includes("|")) {
        filename = cleanText.replace(/--raw/gi, "").trim() || "reply.js";
        content = m.quoted.text;
      } else {
        // format biasa: .gist file|isi
        const [fname, ...contentArr] = cleanText.split("|");
        filename = (fname || "untitled.js").replace(/--raw/gi, "").trim();
        content = contentArr.join("|").trim();
      }

      if (!filename || !content)
        return m.reply(
          `⚙️ *Format salah!*\n\nGunakan format:\n.gist nama_file.js|isi_kode\nAtau reply teks/code dengan:\n.gist nama_file.js\n\nContoh:\n.gist index.js|console.log('Halo dunia!')`
        );

      const isPrivate = argsText.includes("--private");
      const description = `Uploaded via ${conn.user?.name || "ESEMPE-MD"}`;

      const res = await axios.post(
        "https://api.github.com/gists",
        {
          description,
          public: !isPrivate,
          files: {
            [filename]: { content }
          }
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "User-Agent": "ESEMPE-MD"
          }
        }
      );

      const gistUrl = res.data.html_url;
      const rawUrl = res.data.files?.[filename]?.raw_url;

      let msg = `✅ *Berhasil upload ke GitHub Gist!*\n📁 File: ${filename}`;
      if (isRaw && rawUrl) {
        msg += `\n🔗 *Raw URL:* ${rawUrl}`;
      } else {
        msg += `\n🌐 *URL:* ${gistUrl}\n📄 *Raw:* ${rawUrl}`;
      }

      await m.reply(msg);
    } catch (err) {
      console.error(err.response?.data || err.message);
      await m.reply(`❌ *Gagal upload Gist!*\n${err.response?.data?.message || err.message}`);
    }
  }
};