import util from "util";
import crypto from "crypto";
import baileys from "baileys";

export default {
  name: "upswgroup",
  category: "tools",
  command: ["upswgroup", "upswgc"],
  admin: true,

  run: async (conn, m) => {
    try {
      // kalau user tidak reply media/pesan apapun
      if (!m.quoted)
        return m.reply(
          `❌ *Balas gambar, video, audio, stiker, dokumen, atau teks yang ingin diupload ke status grup!*\n\nContoh:\n${m.cmd} (balas media)`
        );

      // gunakan pesan yang dibalas
      const q = m.quoted;

      // ambil mimetype / tipe pesan
      let mime =
        (q.msg || q).mimetype ||
        q.mimetype ||
        q.mediaType ||
        q.type ||
        q.mtype ||
        "";
      mime = mime.toString();

      let content;
      let buffer;

      // deteksi isi media
      if (q.mediaMessage || /image|video|audio|sticker|document/.test(mime) || q.download) {
        buffer = await q.download?.().catch(() => null);
      }

      if (buffer) {
        if (/image/.test(mime) || q.mtype === "imageMessage") {
          content = { image: buffer, caption: q.text || q.caption || "" };
        } else if (/video/.test(mime) || q.mtype === "videoMessage") {
          content = { video: buffer, caption: q.text || q.caption || "" };
        } else if (/audio/.test(mime) || q.mtype === "audioMessage") {
          content = { audio: buffer, mimetype: "audio/mpeg", ptt: false };
        } else if (/sticker/.test(mime) || q.mtype === "stickerMessage") {
          content = { sticker: buffer };
        } else if (/document/.test(mime) || q.mtype === "documentMessage") {
          content = {
            document: buffer,
            mimetype: q.mimetype || "application/octet-stream",
            fileName: q.fileName || "file"
          };
        } else {
          return m.reply("❌ Jenis media tidak didukung untuk status grup!");
        }
      } else if (q.text || q.caption || q.message?.conversation) {
        // fallback untuk teks
        const teks =
          q.text || q.caption || q.message?.conversation || " ";
        content = { text: teks };
      } else {
        return m.reply(
          "❌ *Balas gambar, video, audio, stiker, dokumen, atau teks yang ingin diupload ke status grup!*"
        );
      }

      const loading = await m.reply("⏳ *Mengupload ke status grup...*");

      // buat isi pesan
      const inside = await baileys.generateWAMessageContent(content, {
        upload: conn.waUploadToServer
      });

      const messageSecret = crypto.randomBytes(32);

      const msg = baileys.generateWAMessageFromContent(
        m.chat,
        {
          messageContextInfo: { messageSecret },
          groupStatusMessageV2: {
            message: {
              ...inside,
              messageContextInfo: { messageSecret }
            }
          }
        },
        {}
      );

      // kirim ke WA
      await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

      // selesai
      await conn.sendMessage(m.chat, {
        edit: loading.key,
        text: "✅ *Berhasil upload ke status grup!*"
      });
    } catch (err) {
      console.error("❌ Gagal upload ke status grup:", err);
      m.reply(`⚠️ *Gagal upload ke status grup!*\n${util.format(err)}`);
    }
  }
};