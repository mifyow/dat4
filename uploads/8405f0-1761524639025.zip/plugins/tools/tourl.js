import fs from 'fs'
import axios from 'axios'
import crypto from 'crypto'
import { fileTypeFromBuffer } from 'file-type'

export default {
  name: "tourl",
  category: "tools",
  command: ["tourl", "url"],
  settings: { owner: false },

  run: async (conn, m, { quoted }) => {
    const githubToken = global.githubToken // ambil dari config.js
    const owner = "mifyow" // ganti username GitHub kamu
    const branch = "main"
    let repos = ["dat1", "dat2", "dat3", "dat4"]

    async function ensureRepoExists(repo) {
      try {
        await axios.get(`https://api.github.com/repos/${owner}/${repo}`, {
          headers: { Authorization: `Bearer ${githubToken}` }
        })
      } catch (e) {
        if (e.response?.status === 404) {
          await axios.post(
            `https://api.github.com/user/repos`,
            { name: repo, private: false },
            { headers: { Authorization: `Bearer ${githubToken}` } }
          )
          if (!repos.includes(repo)) repos.push(repo)
        } else throw e
      }
    }

    function generateRepoName() {
      return `dat-${crypto.randomBytes(3).toString('hex')}`
    }

    async function uploadFile(buffer) {
      const detected = await fileTypeFromBuffer(buffer)
      const ext = detected?.ext || "bin"
      const code = crypto.randomBytes(3).toString('hex')
      const fileName = `${code}-${Date.now()}.${ext}`
      const filePathGitHub = `uploads/${fileName}`
      const base64Content = Buffer.from(buffer).toString("base64")

      let targetRepo = repos[Math.floor(Math.random() * repos.length)]
      try {
        await ensureRepoExists(targetRepo)
      } catch {
        targetRepo = generateRepoName()
        await ensureRepoExists(targetRepo)
      }

      await axios.put(
        `https://api.github.com/repos/${owner}/${targetRepo}/contents/${filePathGitHub}`,
        {
          message: `Upload file ${fileName}`,
          content: base64Content,
          branch
        },
        {
          headers: { Authorization: `Bearer ${githubToken}` }
        }
      )

      return `https://raw.githubusercontent.com/${owner}/${targetRepo}/${branch}/${filePathGitHub}`
    }

    try {
      const q = quoted || m
      const mime = (q.msg || q).mimetype || ""
      if (!mime) return m.reply("⚠️ Kirim atau reply media dulu!")

      m.reply("⏳ Uploading ke GitHub...")

      const buffer = await q.download()
      const url = await uploadFile(buffer)

      await m.reply(`✅ *Upload Berhasil!*\n📎 ${url}`)
    } catch (e) {
      console.error(e)
      m.reply(`❌ *Gagal upload!*\n${e.message}`)
    }
  }
}