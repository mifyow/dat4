import fs from 'fs'
import axios from 'axios'
import FormData from 'form-data'
import path from 'path'
import { fileTypeFromBuffer } from 'file-type'

export default {
  name: "tourl2",
  category: "tools",
  command: ["tourl2", "url2", "upload2"],
  settings: { owner: false },

  run: async (conn, m, { quoted, args }) => {
    try {
      const q = quoted || m
      const isAll = args && args[0]?.toLowerCase() === "all"

      const mediaList = []
      if (isAll && m.message.extendedTextMessage?.contextInfo?.quotedMessage) {
        const quotedMsg = m.message.extendedTextMessage.contextInfo.quotedMessage
        const mediaTypes = Object.keys(quotedMsg)
        for (const type of mediaTypes) {
          const qMedia = { msg: quotedMsg[type] }
          mediaList.push(qMedia)
        }
      } else {
        const hasMedia = (q.msg || q).mimetype || (q.message?.imageMessage || q.message?.videoMessage || q.message?.documentMessage || q.message?.audioMessage)
        if (!hasMedia) return m.reply("⚠️ Kirim atau reply media apa pun (gambar, video, dokumen, dll).")
        mediaList.push(q)
      }

      if (!mediaList.length) return m.reply("⚠️ Tidak ada media yang bisa diupload!")

      await m.reply(`☁️ Mengunggah ${mediaList.length} file ke *CloudkuImages*...`)

      const urls = []

      for (const media of mediaList) {
        const buffer = await media.download()
        if (!buffer) {
          urls.push("❌ Gagal download media.")
          continue
        }

        const typeInfo = await fileTypeFromBuffer(buffer)
        const ext = typeInfo?.ext || 'bin'
        const mime = typeInfo?.mime || 'application/octet-stream'

        const tempFile = path.join("/tmp", `upload-${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`)
        fs.writeFileSync(tempFile, buffer)

        const form = new FormData()
        form.append("file", fs.createReadStream(tempFile), {
          filename: `file.${ext}`,
          contentType: mime
        })

        let url
        try {
          let { data } = await axios.post("https://cloudkuimages.guru/upload.php", form, {
            headers: {
              ...form.getHeaders(),
              "User-Agent": "Mozilla/5.0",
              "Referer": "https://cloudkuimages.guru/"
            },
            maxContentLength: Infinity,
            maxBodyLength: Infinity
          })

          if (typeof data === "string") {
            try {
              data = JSON.parse(data)
            } catch {
              data = data.replace(/\\/g, "")
            }
          }

          url = data?.url || data?.link || data?.data?.url || data?.data?.link || data
        } catch (e) {
          console.error("❌ Cloudku error =>", e.message)
          url = "❌ Gagal upload ke cloudkuimages.guru"
        }

        fs.unlinkSync(tempFile)
        urls.push(url)
      }

      // === Kirim hasil ===
      if (urls.length === 1) {
        await m.reply(`✅ *Upload Berhasil!*\n🔗 ${urls[0]}`)
      } else {
        const list = urls.map((u, i) => `${i + 1}. ${u}`).join("\n")
        await m.reply(`✅ *Semua file berhasil diupload!*\n\n${list}`)
      }
    } catch (err) {
      console.error(err)
      m.reply(`❌ *Gagal upload!*\n${err.message}`)
    }
  }
}