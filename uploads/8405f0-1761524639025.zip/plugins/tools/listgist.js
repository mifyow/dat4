import axios from "axios";

export default {
  name: "listgist",
  category: "tools",
  command: ["listgist", "glist", "gists"],
  settings: {
    owner: true
  },
  run: async (conn, m) => {
    try {
      const token = global.githubToken;
      if (!token) return m.reply("⚠️ *Token GitHub belum diset di config.js!* (global.githubToken)");

      const res = await axios.get("https://api.github.com/gists", {
        headers: {
          Authorization: `Bearer ${token}`,
          "User-Agent": "ESEMPE-MD"
        }
      });

      if (!res.data.length) return m.reply("📭 Tidak ada Gist ditemukan di akun GitHub ini.");

      let text = `🗂️ *Daftar Gist Kamu (${res.data.length} total)*\n\n`;
      for (let gist of res.data.slice(0, 10)) { // tampilkan 10 dulu biar rapi
        const id = gist.id;
        const desc = gist.description || "(tanpa deskripsi)";
        const files = Object.keys(gist.files).join(", ");
        text += `📄 *${files}*\n🆔 ID: \`${id}\`\n🔗 ${gist.html_url}\n📜 ${desc}\n\n`;
      }

      if (res.data.length > 10) text += `...dan ${res.data.length - 10} lagi.\nGunakan GitHub langsung untuk lihat semua.`;

      await m.reply(text);
    } catch (err) {
      console.error(err.response?.data || err.message);
      await m.reply(`❌ *Gagal mengambil daftar Gist!*\n${err.response?.data?.message || err.message}`);
    }
  }
};