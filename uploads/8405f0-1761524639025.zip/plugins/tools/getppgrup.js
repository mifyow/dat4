import util from "util"

export default {
  name: "getppgrup",
  category: "tools",
  command: ["getppgrup", "getppgc", "ppgc"],

  run: async (conn, m) => {
    try {
      if (!m.isGroup) return m.reply("❌ *Perintah ini hanya bisa digunakan di grup!*")

      await m.reply("🕐 *Mengambil foto profil grup...*")

      const url = await conn.profilePictureUrl(m.chat, "image").catch(() => null)
      if (!url) return m.reply("⚠️ *Foto profil grup tidak ditemukan!*")

      await conn.sendMessage(m.chat, {
        image: { url },
        caption: "✅ *Berhasil mengambil foto profil grup!*"
      })
    } catch (err) {
      console.error("❌ getppgrup error:", err)
      await m.reply(`⚠️ *Gagal mengambil foto profil grup!*\n${util.format(err)}`)
    }
  }
}