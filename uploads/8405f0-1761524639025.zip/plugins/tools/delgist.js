import axios from "axios";

export default {
  name: "delgist",
  category: "tools",
  command: ["delgist", "gdel", "deletegist"],
  settings: { owner: true },

  run: async (conn, m) => {
    try {
      const token = global.githubToken;
      if (!token)
        return m.reply("⚠️ *Token GitHub belum diset di config.js!* (global.githubToken)");

      // ambil teks dari berbagai sumber
      const fullText =
        m.text ||
        m.body ||
        m.message?.conversation ||
        m.message?.extendedTextMessage?.text ||
        m.args?.join(" ") ||
        m.input ||
        m.quoted?.text ||
        "";

      // hapus prefix + command dari fullText
      const arg = fullText.replace(m.cmd, "").trim().split(" ")[0];

      if (!arg)
        return m.reply(
          `❗ *Masukkan ID Gist atau gunakan 'all' untuk hapus semua!*\n\nContoh:\n> ${m.cmd} 123abc456def789ghi\n> ${m.cmd} all`
        );

      // =========================
      // MODE HAPUS SEMUA GIST
      // =========================
      if (arg.toLowerCase() === "all") {
        await m.reply("🧨 *Menghapus semua Gist... Mohon tunggu*");

        const list = await axios.get("https://api.github.com/gists", {
          headers: {
            Authorization: `Bearer ${token}`,
            "User-Agent": "ESEMPE-MD",
          },
        });

        if (!list.data.length)
          return m.reply("📭 *Tidak ada Gist ditemukan di akun GitHub ini.*");

        let success = 0;
        let fail = 0;

        for (const gist of list.data) {
          try {
            await axios.delete(`https://api.github.com/gists/${gist.id}`, {
              headers: {
                Authorization: `Bearer ${token}`,
                "User-Agent": "ESEMPE-MD",
              },
            });
            success++;
          } catch {
            fail++;
          }
        }

        return m.reply(
          `✅ *Semua Gist selesai dihapus!*\n🗑️ Berhasil: ${success}\n⚠️ Gagal: ${fail}`
        );
      }

      // =========================
      // MODE HAPUS SATU GIST
      // =========================
      const gistId = arg;

      await m.reply(`🗑️ *Menghapus Gist...*\n🆔 ID: ${gistId}`);

      const res = await axios.delete(`https://api.github.com/gists/${gistId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "User-Agent": "ESEMPE-MD",
        },
      });

      if (res.status === 204)
        return m.reply(`✅ *Gist berhasil dihapus!*\n🆔 ID: \`${gistId}\``);

      await m.reply(`⚠️ *Respon tidak terduga dari GitHub!*\nStatus: ${res.status}`);
    } catch (err) {
      console.error(err.response?.data || err.message);
      if (err.response?.status === 404)
        return m.reply("❌ *Gist tidak ditemukan!* Pastikan ID benar.");
      if (err.response?.status === 401)
        return m.reply("❌ *Token GitHub tidak valid!* Periksa config.js.");
      await m.reply(`❌ *Gagal menghapus Gist!*\n${err.response?.data?.message || err.message}`);
    }
  },
};