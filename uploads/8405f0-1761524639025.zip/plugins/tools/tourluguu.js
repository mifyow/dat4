import fs from "fs"
import axios from "axios"
import FormData from "form-data"
import { fileTypeFromBuffer } from "file-type"
import util from "util"

export default {
  name: "tourluguu",
  category: "tools",
  command: ["uguu", "upload2"],
  
  run: async (conn, m) => {
    try {
      // pastikan user balas media
      const q = m.quoted ? m.quoted : m
      const mime = (q.msg || q).mimetype || q.mimetype || ""
      if (!mime) return m.reply("❌ *Balas media yang ingin diupload ke Uguu.se!*")

      // kirim pesan loading
      const loading = await m.reply("☁️ *Mengunggah ke Uguu.se...*")

      // download media buffer
      const buffer = await q.download?.()
      if (!buffer) return m.reply("⚠️ *Gagal mengunduh media!*")

      // deteksi tipe file
      const detected = await fileTypeFromBuffer(buffer)
      const ext = detected?.ext || mime.split("/")[1] || "bin"
      const fileName = `upload_${Date.now()}.${ext}`

      // form unggahan
      const form = new FormData()
      form.append("files[]", buffer, { filename: fileName, contentType: mime })

      // upload ke uguu.se
      const res = await axios.post("https://uguu.se/upload.php", form, {
        headers: form.getHeaders(),
        maxBodyLength: Infinity,
        maxContentLength: Infinity
      })

      // parsing hasil
      let resultUrl = null
      const data = res.data

      if (typeof data === "string" && data.includes("https")) {
        const match = data.match(/https?:\/\/[^\s"']+/)
        resultUrl = match ? match[0] : null
      } else if (data?.files && Array.isArray(data.files)) {
        resultUrl = data.files[0]?.url
      }

      if (!resultUrl) {
        return conn.sendMessage(m.chat, {
          edit: loading.key,
          text: "❌ *Gagal mendapatkan URL dari Uguu.se!*"
        })
      }

      // kirim hasil upload
      await conn.sendMessage(m.chat, {
        edit: loading.key,
        text: `✅ *Berhasil upload ke Uguu.se!*\n\n📄 *Nama File:* ${fileName}\n🔗 *URL:* ${resultUrl}`
      })

      // hapus file sementara
      try { fs.unlinkSync(fileName) } catch {}
    } catch (err) {
      console.error("❌ Upload error:", err)
      await m.reply(`⚠️ *Gagal upload ke Uguu.se!*\n${util.format(err)}`)
    }
  }
}