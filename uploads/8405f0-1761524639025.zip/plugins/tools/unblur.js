import fs from "fs"
import axios from "axios"
import FormData from "form-data"
import crypto from "crypto"
import { fileTypeFromBuffer } from "file-type"

async function uploadToUguu(buffer) {
  const detected = await fileTypeFromBuffer(buffer)
  const ext = detected?.ext || "jpg"
  const mime = detected?.mime || "image/jpeg"
  const fname = `unblur_${Date.now()}.${ext}`

  const form = new FormData()
  form.append("files[]", buffer, { filename: fname, contentType: mime })

  try {
    const res = await axios.post("https://uguu.se/upload.php", form, {
      headers: form.getHeaders(),
      maxContentLength: Infinity,
      maxBodyLength: Infinity
    })
    const data = res.data
    if (typeof data === "string" && data.includes("https")) {
      const match = data.match(/https?:\/\/[^\s]+/g)
      return match ? match[0] : null
    }
    return data.files?.[0]?.url || null
  } catch (e) {
    console.error("❌ Gagal upload ke uguu.se:", e.message)
    return null
  }
}

async function unblurFromUrl(imageUrl) {
  const img = await axios.get(imageUrl, { responseType: "arraybuffer" })
  const buffer = Buffer.from(img.data)
  const serial = crypto.randomBytes(16).toString("hex")
  const fname = `Image_${crypto.randomBytes(6).toString("hex")}.jpg`
  const form = new FormData()
  form.append("original_image_file", buffer, { filename: fname, contentType: "image/jpeg" })
  form.append("scale_factor", 2)
  form.append("upscale_type", "image-upscale")
  const headers = { ...form.getHeaders(), "product-serial": serial }

  try {
    const res = await axios.post("https://api.unblurimage.ai/api/imgupscaler/v2/ai-image-unblur/create-job", form, { headers })
    const jobId = res.data?.result?.job_id
    if (!jobId) throw new Error("Job ID not found")

    let output, done = false
    const timeout = Date.now() + 180000
    while (!done && Date.now() < timeout) {
      const poll = await axios.get(`https://api.unblurimage.ai/api/imgupscaler/v2/ai-image-unblur/get-job/${jobId}`, { headers })
      if (poll.data.code === 100000 && poll.data.result?.output_url?.[0]) {
        output = poll.data.result.output_url[0]
        done = true
      } else await new Promise(r => setTimeout(r, 3000))
    }
    return { jobId, filename: fname, output }
  } catch (e) {
    console.error("❌ Unblur error =>", e.response?.data || e.message)
    return { error: e.response?.data || e.message }
  }
}

export default {
  name: "unblur",
  category: "tools",
  command: ["unblur", "clearimg", "enhance", "fiximg"],
  settings: { owner: false },

  run: async (conn, m, { quoted, text }) => {
    try {
      let imageUrl
      const q = quoted || m
      const mime = (q.msg || q).mimetype || ""

      if (!text && !mime.startsWith("image/"))
        return m.reply("⚠️ Kirim atau reply gambar yang ingin di-*unblur*!")

      const statusMsg = await m.reply("☁️ Mengunggah gambar ke *Uguu.se*...")

      if (text && text.startsWith("http")) {
        imageUrl = text.trim()
      } else {
        const buffer = await q.download()
        imageUrl = await uploadToUguu(buffer)
        if (!imageUrl)
          return conn.sendMessage(m.chat, { text: "❌ Gagal upload ke Uguu.se!", edit: statusMsg.key })
      }

      await conn.sendMessage(m.chat, { text: "✨ Memproses gambar di *UnblurImage.ai*...", edit: statusMsg.key })

      const result = await unblurFromUrl(imageUrl)

      if (result?.output) {
        // Edit pesan status terakhir ke "Selesai"
        await conn.sendMessage(m.chat, { text: "✅ *Berhasil memproses gambar!*", edit: statusMsg.key })

        // Kirim hasil gambar sebagai pesan baru
        await conn.sendMessage(m.chat, {
          image: { url: result.output },
          caption: `✅ *Berhasil!*\n🖼️ Gambar: ${result.filename}\n🔗 URL: ${result.output}`
        }, { quoted: m })
      } else {
        await conn.sendMessage(m.chat, { text: `❌ *Gagal memproses gambar!*\n${result?.error || "Unknown error"}`, edit: statusMsg.key })
      }
    } catch (err) {
      console.error(err)
      await m.reply(`❌ *Error:* ${err.message}`)
    }
  }
}