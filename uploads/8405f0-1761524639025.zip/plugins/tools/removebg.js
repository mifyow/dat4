import fs from "fs";
import axios from "axios";
import FormData from "form-data";

export default {
    name: "removebg",
    category: "tools",
    command: ["removebg", "rmbg"],
    settings: {
        owner: false
    },
    run: async (conn, m, { quoted }) => {
        try {
            const q = m.quoted || m;
            const mime = (q.msg || q).mimetype || "";
            if (!mime.startsWith("image/")) {
                return m.reply("📸 Balas atau kirim gambar dengan caption *.removebg*");
            }

            // Pastikan folder Tmp ada
            const tmpDir = "./Tmp";
            if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);

            const media = await conn.downloadMediaMessage(q);
            const tempFile = `${tmpDir}/removebg_${Date.now()}.jpg`;
            fs.writeFileSync(tempFile, media);

            await m.reply("🪄 Sedang menghapus background, tunggu sebentar...");

            const form = new FormData();
            form.append("file", fs.createReadStream(tempFile));

            const { data } = await axios.post(
                "https://api.mifinfinity.my.id/api/tools/removebg",
                form,
                { headers: form.getHeaders(), timeout: 60000 }
            );

            fs.unlinkSync(tempFile);

            if (!data?.results?.localFile) {
                console.log("❌ API Response:", data);
                return m.reply("⚠️ Gagal mendapatkan hasil dari API (data kosong).");
            }

            const resultUrl = data.results.localFile;
            const resultImage = await axios.get(resultUrl, { responseType: "arraybuffer" });

            await conn.sendMessage(
                m.chat,
                {
                    image: Buffer.from(resultImage.data),
                    caption: `✅ Background berhasil dihapus!\n📎 *File:* ${data.results.filename}\n🖋️ ${data.attribution || ""}`
                },
                { quoted: m }
            );
        } catch (err) {
            console.error("🔥 REMOVE BG ERROR:", err.response?.data || err.message || err);
            m.reply("❌ Terjadi kesalahan saat memproses gambar.\nCek console/log untuk detail.");
        }
    }
};