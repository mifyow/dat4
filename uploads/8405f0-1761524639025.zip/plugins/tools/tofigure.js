/**
 * CR Ahzamycode
 * Convert Image → Figure (AI)
 * Command : .tofigure
 */

import fs from "fs";
import path from "path";
import axios from "axios";
import FormData from "form-data";

export default {
  name: "tofigure",
  category: "tools",
  command: ["tofigure"],
  settings: {
    owner: false,
  },

  run: async (conn, m, { quoted }) => {
    try {
      const q = m.quoted || quoted;
      const mime = (q?.msg || q)?.mimetype || "";

      if (!mime.startsWith("image/"))
        return m.reply("⚠️ Kirim atau balas gambar yang ingin dikonversi menjadi figure!");

      await m.reply("⏳ Sedang memproses gambar...");

      // Pastikan folder Tmp ada
      const tmpDir = "./Tmp";
      if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

      // Download gambar dari quoted
      const buffer = await conn.downloadMediaMessage(q);
      const inputPath = path.join(tmpDir, `figure_${Date.now()}.jpg`);
      fs.writeFileSync(inputPath, buffer);

      // Upload ke Uguu
      const form = new FormData();
      form.append("files[]", fs.createReadStream(inputPath));

      const uploadRes = await axios.post("https://uguu.se/upload.php", form, {
        headers: form.getHeaders(),
      });

      if (!uploadRes.data.files || !uploadRes.data.files[0]?.url)
        throw new Error("Gagal mengunggah ke Uguu.se!");

      const imageUrl = uploadRes.data.files[0].url;
      const encodedUrl = encodeURIComponent(imageUrl);

      // Request ke API Convert → Figure
      const apiRes = await axios.get(
        `https://api.nekolabs.my.id/tools/convert/tofigure?imageUrl=${encodedUrl}`
      );

      if (!apiRes.data?.result)
        throw new Error("Gagal mendapatkan hasil konversi dari API!");

      const resultUrl = apiRes.data.result;

      // Kirim hasil ke chat
      await conn.sendMessage(
        m.chat,
        { image: { url: resultUrl }, caption: "✅ Gambar berhasil dikonversi menjadi figure!" },
        { quoted: m }
      );

      // Bersihkan file temporer
      try {
        fs.unlinkSync(inputPath);
      } catch {}

    } catch (err) {
      console.error("TOFIGURE ERROR:", err);
      await m.reply(`❌ Terjadi kesalahan: ${err.message}`);
    }
  },
};