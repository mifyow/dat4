export default {
    name: "bratanime",
    category: "sticker",
    command: ["bratanime", "banime"],
    run: async (conn, m) => {
        if (!m.text) return m.reply('Masukkan teks yang valid!\nContoh: .bratanime aku ganteng');

        try {
            // encode teks biar aman untuk URL
            const text = encodeURIComponent(m.text.trim());
            const apiUrl = `https://www.veloria.my.id/imagecreator/bratanime?text=${text}`;

            await conn.sendSticker(m.chat, apiUrl, m);
        } catch (err) {
            console.error('Error:', err);
            m.reply('⚠️ Gagal membuat stiker Brat Anime!');
        }
    }
};