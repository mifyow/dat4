import fs from 'fs';
import path from 'path';

export default {
    name: "sfp",
    category: "owner",
    command: ["sfp", "safeplugin"],
    settings: {
        owner: true
    },
    run: async (conn, m, { quoted }) => {
        if (!m.text) return m.reply(`Nama filenya??\nContoh: ${m.cmd} folder/namafile`);
        if (!quoted?.body) return m.reply(`Balas pesan yang berisi kode plugin!`);

        const filePath = path.join('./plugins', `${m.text}.js`);
        const dirPath = path.dirname(filePath);

        if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
        }

        fs.writeFileSync(filePath, quoted.body);
        m.reply(`✅ Plugin tersimpan di: ${filePath}`);
    }
}