import fs from "fs";

export default {
  name: "clearsession",
  category: "owner",
  command: ["clearsession", "clsesi", "clearsesion"],
  settings: {
    owner: true
  },
  run: async (conn, m) => {
    try {
      const sessionFiles = fs.readdirSync("./sessions").filter(f => f !== "creds.json");
      if (sessionFiles.length === 0) return m.reply("Tidak ada sampah session ditemukan ✅");

      await m.reply(`${sessionFiles.length} sampah session ditemukan\n🧹 Memproses penghapusan...`);

      for (const file of sessionFiles) {
        fs.unlinkSync(`./sessions/${file}`);
      }

      await new Promise(r => setTimeout(r, 3500));
      return m.reply(`Sukses membersihkan ${sessionFiles.length} sampah session ✅`);
    } catch (err) {
      return m.reply(`⚠️ Terjadi kesalahan: ${err.message}`);
    }
  }
};