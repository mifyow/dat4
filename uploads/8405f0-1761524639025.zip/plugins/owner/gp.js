import fs from 'fs';
import path from 'path';

export default {
    name: "getplugin",
    category: "owner",
    command: ["getplugin", "gp"],
    settings: {
        owner: true
    },
    run: async (conn, m) => {
        if (!m.text) return m.reply(`Nama filenya??\nContoh: ${m.cmd} folder/namafile`);
        
        const filePath = path.join('./plugins', `${m.text}.js`);

        if (!fs.existsSync(filePath)) {
            return m.reply(`❌ File *${filePath}* tidak ditemukan!`);
        }

        try {
            const content = fs.readFileSync(filePath, 'utf-8');
            
            if (content.length > 4000) {
                // kalau isi file panjang, kirim sebagai dokumen
                await conn.sendMessage(m.chat, {
                    document: { url: filePath },
                    mimetype: 'application/javascript',
                    fileName: path.basename(filePath)
                }, { quoted: m });
            } else {
                await m.reply(`📄 *Isi Plugin:* ${m.text}.js\n\n\`\`\`js\n${content}\n\`\`\``);
            }
        } catch (err) {
            m.reply(`⚠️ Gagal membaca file!\nError: ${err.message}`);
        }
    }
}