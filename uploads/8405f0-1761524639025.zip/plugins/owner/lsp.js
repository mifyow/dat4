import fs from 'fs';
import path from 'path';

export default {
    name: "listplugin",
    category: "owner",
    command: ["listplugin", "lsp"],
    settings: {
        owner: true
    },
    run: async (conn, m) => {
        const pluginDir = './plugins';
        
        try {
            if (!fs.existsSync(pluginDir)) {
                return m.reply(`Folder plugin (${pluginDir}) tidak ditemukan!`);
            }

            const getFiles = (dir) => {
                const files = fs.readdirSync(dir);
                let all = [];
                for (let file of files) {
                    const filePath = path.join(dir, file);
                    const stat = fs.statSync(filePath);
                    if (stat.isDirectory()) {
                        all.push(...getFiles(filePath)); // ambil isi subfolder
                    } else if (file.endsWith('.js')) {
                        all.push(filePath.replace('./plugins/', '').replace(/\\/g, '/'));
                    }
                }
                return all;
            };

            const allPlugins = getFiles(pluginDir);
            if (allPlugins.length === 0) return m.reply(`Tidak ada plugin ditemukan di folder ${pluginDir}`);

            let teks = `📦 *Daftar Plugin (${allPlugins.length})*\n\n`;
            teks += allPlugins.map((f, i) => `${i + 1}. ${f}`).join('\n');

            await m.reply(teks);
        } catch (err) {
            m.reply(`Terjadi kesalahan saat membaca plugin:\n${err.message}`);
        }
    }
}