import fs from "fs";
import { execSync } from "child_process";

export default {
    name: "backup",
    category: "owner",
    command: ["backup", "bck", "backupsc"],
    settings: {
        owner: true
    },
    run: async (conn, m) => {
        try {
            const tmpDir = "./Tmp";
            if (fs.existsSync(tmpDir)) {
                const files = fs.readdirSync(tmpDir).filter(f => !f.endsWith(".js"));
                for (let file of files) {
                    fs.unlinkSync(`${tmpDir}/${file}`);
                }
            }

            await m.reply("📦 *Processing Backup Script...*");

            const name = "Mif-Script";
            const exclude = [
                "node_modules",
                "sessions",
                "yarn.lock",
                ".npm",
                ".cache"
            ];

            const filesToZip = fs.readdirSync(".").filter(f => !exclude.includes(f) && f !== "");

            if (!filesToZip.length) return m.reply("⚠️ Tidak ada file yang dapat di-backup.");

            execSync(`zip -r ${name}.zip ${filesToZip.join(" ")}`);

            await conn.sendMessage(m.chat, {
                document: fs.readFileSync(`./${name}.zip`),
                fileName: `${name}.zip`,
                mimetype: "application/zip"
            }, { quoted: m });

            fs.unlinkSync(`./${name}.zip`);

            await m.reply("✅ Backup selesai dan dikirim.");
        } catch (err) {
            console.error(err);
            await m.reply("⚠️ Terjadi kesalahan saat melakukan backup.");
        }
    }
};